Attribute VB_Name = "Modulo_Automatizacion"
'=====================================================
' KIT DE AUTOMATIZACION VBA - E.P.E.T. N7 (EPJA)
' Prof. Ruben Markwart - Tecnicatura en Informatica
' Importar con: Alt+F11 - Archivo - Importar archivo
'=====================================================
Option Explicit

'--- EJERCICIO 1: Resaltar filas alternas (bucle For) ---
Sub ResaltarFilasAlternas()
    Dim rng As Range
    Dim fila As Long
    
    Set rng = Selection
    
    For fila = 1 To rng.Rows.Count
        If fila Mod 2 = 0 Then
            rng.Rows(fila).Interior.Color = RGB(232, 241, 236)
        Else
            rng.Rows(fila).Interior.ColorIndex = xlNone
        End If
    Next fila
    
    MsgBox "Formato cebra aplicado a " & rng.Rows.Count & " filas.", vbInformation
End Sub

'--- EJERCICIO 3: Consolidar hojas en una Maestra ---
Sub ConsolidarHojas()
    Dim hojaMaestra As Worksheet
    Dim hoja As Worksheet
    Dim ultimaFila As Long
    Dim destino As Long
    
    Application.DisplayAlerts = False
    On Error Resume Next
    ThisWorkbook.Sheets("Maestra").Delete
    On Error GoTo 0
    Application.DisplayAlerts = True
    
    Set hojaMaestra = ThisWorkbook.Sheets.Add(Before:=ThisWorkbook.Sheets(1))
    hojaMaestra.Name = "Maestra"
    destino = 1
    
    For Each hoja In ThisWorkbook.Worksheets
        ' Solo consolida las hojas de cursos
        If hoja.Name Like "Curso_*" Then
            ultimaFila = hoja.Cells(hoja.Rows.Count, "A").End(xlUp).Row
            
            If destino = 1 Then
                hoja.Range("A1", hoja.Cells(ultimaFila, 3)).Copy hojaMaestra.Cells(1, 1)
                destino = ultimaFila + 1
            ElseIf ultimaFila > 1 Then
                hoja.Range("A2", hoja.Cells(ultimaFila, 3)).Copy hojaMaestra.Cells(destino, 1)
                destino = destino + ultimaFila - 1
            End If
        End If
    Next hoja
    
    MsgBox "Consolidacion completa: " & destino - 2 & " registros en 'Maestra'.", vbInformation
End Sub

'--- EJERCICIO 4: Proteger / desproteger todas las hojas ---
Sub ProtegerTodasLasHojas()
    Dim hoja As Worksheet
    Dim clave As String
    
    clave = InputBox("Ingresa la contrasena para proteger todas las hojas:")
    If clave = "" Then Exit Sub
    
    For Each hoja In ThisWorkbook.Worksheets
        hoja.Protect Password:=clave, AllowSorting:=False, AllowFiltering:=True
    Next hoja
    
    MsgBox ThisWorkbook.Worksheets.Count & " hojas protegidas.", vbInformation
End Sub

Sub DesprotegerTodasLasHojas()
    Dim hoja As Worksheet
    Dim clave As String
    
    clave = InputBox("Ingresa la contrasena para desproteger:")
    
    On Error Resume Next
    For Each hoja In ThisWorkbook.Worksheets
        hoja.Unprotect Password:=clave
    Next hoja
    On Error GoTo 0
End Sub

'--- EJERCICIO 5: Boton Reiniciar (filtros + formulario) ---
Sub ReiniciarPlanilla()
    Dim hoja As Worksheet
    
    For Each hoja In ThisWorkbook.Worksheets
        If hoja.FilterMode Then hoja.ShowAllData
        If hoja.AutoFilterMode Then hoja.AutoFilter.ShowAllData
    Next hoja
    
    On Error Resume Next
    ThisWorkbook.Sheets("Carga").Range("Formulario").ClearContents
    On Error GoTo 0
    
    MsgBox "Filtros limpiados y formulario vaciado. Listo para el proximo turno.", vbInformation
End Sub

'--- EJERCICIO 6: Exportar seleccion a PDF ---
Sub ExportarSeleccionAPDF()
    Dim rutaArchivo As String
    
    rutaArchivo = ThisWorkbook.Path & Application.PathSeparator & _
                  "Reporte_" & Format(Date, "yyyy-mm-dd") & ".pdf"
    
    Selection.ExportAsFixedFormat _
        Type:=xlTypePDF, _
        Filename:=rutaArchivo, _
        Quality:=xlQualityStandard, _
        IgnorePrintAreas:=True, _
        OpenAfterPublish:=True
    
    MsgBox "PDF generado en:" & vbNewLine & rutaArchivo, vbInformation
End Sub
